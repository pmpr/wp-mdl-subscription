<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4257dc371             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Model; use Pmpr\Common\Foundation\ORM\DB\Model; use Pmpr\Module\Subscription\Interfaces\CommonInterface; abstract class Common extends Model implements CommonInterface { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($wksoawcgagcgoask)->wiskakymeaywyeuw($wksoawcgagcgoask); } }
