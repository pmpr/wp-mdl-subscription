<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e626f3e6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\x6e\x5f\x69\x6e\151\x74", [$this, "\145\x6e\x71\x75\145\x75\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\144\155\151\156", $eygsasmqycagyayw->get("\x61\x64\x6d\x69\156\56\x6a\163"))->okawmmwsiuauwsiu()); } }
