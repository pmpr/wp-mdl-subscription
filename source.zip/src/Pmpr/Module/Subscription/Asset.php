<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4257dc371             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\137\x69\x6e\x69\x74", [$this, "\145\x6e\161\x75\145\x75\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\144\155\x69\x6e", $eygsasmqycagyayw->get("\x61\144\x6d\x69\x6e\56\x6a\x73"))->okawmmwsiuauwsiu()); } }
