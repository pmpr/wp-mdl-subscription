<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5706d0d96             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\x6e\x5f\151\x6e\151\x74", [$this, "\145\x6e\x71\x75\145\x75\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\155\151\x6e", $eygsasmqycagyayw->get("\x61\144\x6d\151\156\x2e\x6a\163"))->okawmmwsiuauwsiu()); } }
