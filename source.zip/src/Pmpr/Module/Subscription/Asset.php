<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069b4aa0dee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\x6e\137\151\x6e\151\x74", [$this, "\x65\x6e\161\x75\x65\165\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\144\x6d\151\156", $eygsasmqycagyayw->get("\x61\x64\x6d\x69\x6e\x2e\x6a\x73"))->okawmmwsiuauwsiu()); } }
