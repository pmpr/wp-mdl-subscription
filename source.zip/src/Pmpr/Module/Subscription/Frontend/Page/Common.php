<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11c7db297             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\Subscription\Setting; abstract class Common extends Page { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
