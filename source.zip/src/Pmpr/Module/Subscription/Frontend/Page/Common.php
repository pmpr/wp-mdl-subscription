<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069b4aa0dee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Module\Subscription\Interfaces\CommonInterface; use Pmpr\Module\Subscription\Setting; abstract class Common extends Page implements CommonInterface { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
