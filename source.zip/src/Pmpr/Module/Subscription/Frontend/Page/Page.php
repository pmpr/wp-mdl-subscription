<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646b877de0f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Module\Subscription\Frontend\Common; class Page extends Common { public function mameiwsayuyquoeq() { Viewer::symcgieuakksimmu(); Pricing::symcgieuakksimmu(); } }
