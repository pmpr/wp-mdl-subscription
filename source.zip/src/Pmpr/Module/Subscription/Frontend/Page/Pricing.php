<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4d7fa46             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Subscription\Model\Plan; use Pmpr\Module\Subscription\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Pricing extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x70\162\151\x63\x69\x6e\147")->gswweykyogmsyawy(__("\x50\x72\x69\143\x69\156\x67", PR__MDL__SUBSCRIPTION))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::usyscuksyoimmsyy)); parent::qiccuiwooiquycsg(); } public function rsysgcucogueguuk() : array { $omouioamescuegke = Plan::symcgieuakksimmu(); return ["\x70\x6c\141\x6e\163" => $omouioamescuegke->qyaiiayimwmuomey(), "\146\145\141\x74\x75\162\x65\137\151\143\x6f\156" => IconInterface::ggokgkyiweugsokc, Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::ysgwugcqguggmigq), Constants::eqkeooqcsscoggia => $this->weysguygiseoukqw(Setting::bweaoswakkswcwms), Constants::uookioyeieiswoew => Constants::uookioyeieiswoew === $this->weysguygiseoukqw(Setting::quaagiciyoskcygq)]; } }
