<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687084e50a38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend; use Pmpr\Module\Subscription\Container; abstract class Common extends Container { }
