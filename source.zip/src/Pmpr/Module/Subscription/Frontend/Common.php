<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7e3b6cd24             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend; use Pmpr\Module\Subscription\Container; abstract class Common extends Container { }
