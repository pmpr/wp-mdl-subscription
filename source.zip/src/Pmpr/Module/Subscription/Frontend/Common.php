<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7a74fa7e77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend; use Pmpr\Module\Subscription\Container; abstract class Common extends Container { }
